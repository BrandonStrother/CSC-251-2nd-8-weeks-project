/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tablechair_groupproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author strotheb6455
 */
public class TableChair_GroupProject
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        new OrderForm().setVisible(true);
    }   
     
    
}
